import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth'
import { getStorage } from "firebase/storage";
import {getFirestore} from 'firebase/firestore';

const firebaseConfig = {

  apiKey: "AIzaSyAoL7-3dNR7c8XfLAK7uaGppBORgytZjyk",

  authDomain: "chat-c509d.firebaseapp.com",

  projectId: "chat-c509d",

  storageBucket: "chat-c509d.appspot.com",

  messagingSenderId: "342561253962",

  appId: "1:342561253962:web:f7ad86a832c65edc9954b3"

};


// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth()
export const storage = getStorage();
export const db = getFirestore()