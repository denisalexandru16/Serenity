import React, { useState } from "react";
import Add from "../img/addAvatar.svg";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth, db, storage } from "../firebase";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { doc, setDoc } from "firebase/firestore";
import { useNavigate, Link } from "react-router-dom";
import Logo from '../img/Logo.svg'

const Register = () => {
  const [err, setErr] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();


  const backToGallery = () => {
    window.location.href = 'http://localhost/';
  };


  const handleSubmit = async (e) => {
    setLoading(true);
    e.preventDefault();
    const displayName = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    const file = e.target[3].files[0];

    try {
      //Create user
      const res = await createUserWithEmailAndPassword(auth, email, password);

      //Create a unique image name
      const date = new Date().getTime();
      const storageRef = ref(storage, `${displayName + date}`);

      // Check if a file is selected
      if (file) {
        // Upload image to storage and update profile with photoURL
        await uploadBytesResumable(storageRef, file).then(() => {
          getDownloadURL(storageRef).then(async (downloadURL) => {
            try {
              await updateProfile(res.user, {
                displayName,
                photoURL: downloadURL,
              });
              await setDoc(doc(db, "users", res.user.uid), {
                uid: res.user.uid,
                displayName,
                email,
                photoURL: downloadURL,
              });
              await setDoc(doc(db, "userChats", res.user.uid), {});
              navigate("/");
            } catch (err) {
              console.log(err);
              setErr(true);
              setLoading(false);
            }
          });
        });
      } else {
        // Update profile without photoURL and create user data without photoURL
        await updateProfile(res.user, {
          displayName,
        });
        await setDoc(doc(db, "users", res.user.uid), {
          uid: res.user.uid,
          displayName,
          email,
        });
        await setDoc(doc(db, "userChats", res.user.uid), {});
        navigate("/");
      }
    } catch (err) {
      setErr(true);
      setLoading(false);
    }
  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <span className="logo">
            <img 
            src={Logo} 
            alt=""
            onClick={backToGallery}
            /> 
        </span>
        <span className="title">Înregistrare</span>
        <form onSubmit={handleSubmit}>
          <input required type="text" placeholder="Numele de utilizator" />
          <input required type="email" placeholder="Email" />
          <input required type="password" placeholder="Parola" />
          <input style={{ display: "none" }} type="file" id="file" />
          <label htmlFor="file">
            <img src={Add} alt="" />
            <span>Adaugați o poză de profil</span>
          </label>
          <button disabled={loading}>Inregistreaza-te</button>
          {loading && "Se prelucrează imaginea, vă rog să așteptați..."}
          {err && <span>Ceva a mers gresit!</span>}
        </form>
        <p>
          Ai cont? <Link to="/login">Loghează-te</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
