import React, { useContext } from "react";
import Messages from "./Messages";
import Input from "./Input";
import { ChatContext } from "../context/ChatContext";


const Chat = () => {
  const { data } = useContext(ChatContext);
  

  const backToGallery = () => {
    window.location.href = 'http://localhost/';
  };
  
  const toSupport = () =>{
    window.location.href='http://localhost/suport'
  }
  return (
    <div className="chat">
      <div className="chatInfo">
        <span>{data.user?.displayName}</span>
        <div className="chatIcons">
          <button onClick={backToGallery}>Serenity Gallery</button>
          <button onClick={toSupport}>Suport</button>
        </div>
      </div>
      <Messages />
      <Input/>
    </div>
  );
};

export default Chat;
